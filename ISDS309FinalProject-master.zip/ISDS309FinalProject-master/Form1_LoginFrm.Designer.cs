﻿namespace ISDS309FinalProject
{
    partial class Form1_LoginFrm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            usernameLbl = new Label();
            passwordLbl = new Label();
            usernameTxt = new TextBox();
            passwordTxt = new TextBox();
            loginBtn = new Button();
            createAccountBtn = new Button();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // usernameLbl
            // 
            usernameLbl.AutoSize = true;
            usernameLbl.Location = new Point(119, 152);
            usernameLbl.Margin = new Padding(4, 0, 4, 0);
            usernameLbl.Name = "usernameLbl";
            usernameLbl.Size = new Size(89, 25);
            usernameLbl.TabIndex = 0;
            usernameLbl.Text = "username";
            // 
            // passwordLbl
            // 
            passwordLbl.AutoSize = true;
            passwordLbl.Location = new Point(119, 209);
            passwordLbl.Margin = new Padding(4, 0, 4, 0);
            passwordLbl.Name = "passwordLbl";
            passwordLbl.Size = new Size(89, 25);
            passwordLbl.TabIndex = 1;
            passwordLbl.Text = "password";
            passwordLbl.Click += label2_Click;
            // 
            // usernameTxt
            // 
            usernameTxt.Location = new Point(241, 152);
            usernameTxt.Margin = new Padding(4);
            usernameTxt.Name = "usernameTxt";
            usernameTxt.Size = new Size(155, 31);
            usernameTxt.TabIndex = 2;
            usernameTxt.TextChanged += usernameTxt_TextChanged;
            // 
            // passwordTxt
            // 
            passwordTxt.Location = new Point(241, 209);
            passwordTxt.Margin = new Padding(4);
            passwordTxt.Name = "passwordTxt";
            passwordTxt.Size = new Size(155, 31);
            passwordTxt.TabIndex = 3;
            // 
            // loginBtn
            // 
            loginBtn.Location = new Point(241, 365);
            loginBtn.Margin = new Padding(4);
            loginBtn.Name = "loginBtn";
            loginBtn.Size = new Size(118, 36);
            loginBtn.TabIndex = 4;
            loginBtn.Text = "Login";
            loginBtn.UseVisualStyleBackColor = true;
            loginBtn.Click += loginBtn_Click;
            // 
            // createAccountBtn
            // 
            createAccountBtn.Location = new Point(241, 423);
            createAccountBtn.Margin = new Padding(4);
            createAccountBtn.Name = "createAccountBtn";
            createAccountBtn.Size = new Size(211, 39);
            createAccountBtn.TabIndex = 5;
            createAccountBtn.Text = "Create Account";
            createAccountBtn.UseVisualStyleBackColor = true;
            createAccountBtn.Click += createBtn_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.project_logo;
            pictureBox1.Location = new Point(530, 118);
            pictureBox1.Margin = new Padding(4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(331, 301);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 6;
            pictureBox1.TabStop = false;
            // 
            // loginFrm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1000, 562);
            Controls.Add(pictureBox1);
            Controls.Add(createAccountBtn);
            Controls.Add(loginBtn);
            Controls.Add(passwordTxt);
            Controls.Add(usernameTxt);
            Controls.Add(passwordLbl);
            Controls.Add(usernameLbl);
            Margin = new Padding(4);
            Name = "loginFrm";
            Text = "Welcome to CSUF Credit Union";
            Load += loginFrm_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label usernameLbl;
        private Label passwordLbl;
        private TextBox usernameTxt;
        private TextBox passwordTxt;
        private Button loginBtn;
        private Button createAccountBtn;
        private PictureBox pictureBox1;
    }
}
