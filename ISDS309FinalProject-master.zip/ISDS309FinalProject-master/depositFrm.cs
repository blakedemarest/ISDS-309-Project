﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ISDS309FinalProject.Form1_LoginFrm;

namespace ISDS309FinalProject
{
    public partial class depositFrm : Form
    {
        public depositFrm()
        {
            InitializeComponent();
            this.FormClosing += FormUtilities.CloseFormHandler;
        }



        private void ShowForm(Form form)
        {
            this.Hide(); // Hide the main menu
            form.FormClosed += (s, args) => this.Show(); // Show the main menu again when the form is closed
            form.Show(); // Show the form
        }

        public bool UpdateAccountBalanceDeposit(double amount, out double remainingBalance)
        {
            string allUsersFilePath = "All_User_Accounts.txt";
            string tempFilePath = Path.GetTempFileName();
            bool updateSuccessful = false;
            remainingBalance = 0.0;  // Initialize remaining balance
            double currentBalance = 0;
            string username = UserSession.CurrentUsername;
            string accountType = UserSession.CheckingAccount ? "Checking" : "Savings";

            try
            {
                string[] lines = File.ReadAllLines(allUsersFilePath);
                using (StreamWriter writer = new StreamWriter(tempFilePath))
                {
                    bool isUserFound = false;

                    for (int i = 0; i < lines.Length; i++)
                    {
                        if (isUserFound)
                        {
                            if (lines[i].StartsWith(accountType + " Account Balance:"))
                            {
                                string balanceString = lines[i].Split('$')[1].Trim();
                                currentBalance = double.Parse(balanceString);

                                currentBalance += amount;
                                lines[i] = $"{accountType} Account Balance: ${currentBalance:0.00}";
                                writer.WriteLine(lines[i]);
                                updateSuccessful = true;
                                remainingBalance = currentBalance;  // Update the remaining balance
                                continue;

                            }
                        }

                        if (lines[i].StartsWith("Username: ") && lines[i].Substring(10).Trim().Equals(username))
                        {
                            isUserFound = true;
                        }

                        writer.WriteLine(lines[i]);
                    }
                }

                if (updateSuccessful)
                {
                    File.Copy(tempFilePath, allUsersFilePath, true);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating account balance: {ex.Message}\nCurrent Balance: ${currentBalance:0.00}");
            }
            finally
            {
                File.Delete(tempFilePath);
            }

            return updateSuccessful;
        }

        private void DepositMessage(double amount)
        {
            string accountType = UserSession.CheckingAccount ? "Checking" : "Savings";  // Determine the account type
                                                                                        // Prompt the user to confirm the deposit
            DialogResult result = MessageBox.Show($"Are you sure you want to deposit ${amount:0.00} into your {accountType} account?", "Confirm deposit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // Check the user's response
            if (result == DialogResult.Yes)
            {
                double remainingBalance;
                UpdateAccountBalanceDeposit(amount, out remainingBalance);
                MessageBox.Show($"Successfully deposited ${amount} into your account!");
            }
            else
            {
                MessageBox.Show("deposit cancelled.", "Transaction Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            ShowForm(new mainmenuFrm());
        }

        private void depositFrm_Load(object sender, EventArgs e)
        {

        }

        private void fortyBtn_Click_1(object sender, EventArgs e)
        {
            DepositMessage(40.00);
        }

        private void eightyBtn_Click_1(object sender, EventArgs e)
        {
            DepositMessage(80.00);
        }

        private void hundredBtn_Click_1(object sender, EventArgs e)
        {
            DepositMessage(100.00);
        }

        private void twohundredBtn_Click_1(object sender, EventArgs e)
        {
            DepositMessage(200.00);
        }

        private void otherBtn_Click_1(object sender, EventArgs e)
        {
            string input = Microsoft.VisualBasic.Interaction.InputBox("Enter the amount to deposit:", "deposit", "0", -1, -1);
            if (double.TryParse(input, out double customAmount) && customAmount > 0)
            {
                DepositMessage(customAmount);
            }
            else
            {
                MessageBox.Show("Invalid amount entered.");
            }
        }

        private void cancelBtn_Click_1(object sender, EventArgs e)
        {
            ShowForm(new mainmenuFrm());
        }
    }
}
