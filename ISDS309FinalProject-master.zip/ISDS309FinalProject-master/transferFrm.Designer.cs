﻿namespace ISDS309FinalProject
{
    partial class transferFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            AmountTxt = new TextBox();
            pictureBox1 = new PictureBox();
            OKBtn = new Button();
            fromLbl = new Label();
            accountBox = new ComboBox();
            accountBox2 = new ComboBox();
            label2 = new Label();
            label1 = new Label();
            transferAmt = new TextBox();
            cancelBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // AmountTxt
            // 
            AmountTxt.Font = new Font("Segoe UI", 9F, FontStyle.Italic, GraphicsUnit.Point, 0);
            AmountTxt.Location = new Point(133, 103);
            AmountTxt.Margin = new Padding(4, 3, 4, 3);
            AmountTxt.Name = "AmountTxt";
            AmountTxt.Size = new Size(271, 31);
            AmountTxt.TabIndex = 1;
            AmountTxt.Text = "Enter $ Amount";
            AmountTxt.TextAlign = HorizontalAlignment.Center;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.project_logo;
            pictureBox1.Location = new Point(567, 103);
            pictureBox1.Margin = new Padding(4, 3, 4, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(356, 358);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // OKBtn
            // 
            OKBtn.BackColor = SystemColors.ActiveCaption;
            OKBtn.Location = new Point(133, 405);
            OKBtn.Margin = new Padding(4, 3, 4, 3);
            OKBtn.Name = "OKBtn";
            OKBtn.Size = new Size(179, 57);
            OKBtn.TabIndex = 10;
            OKBtn.Text = "OK";
            OKBtn.UseVisualStyleBackColor = false;
            OKBtn.Click += OKBtn_Click;
            // 
            // fromLbl
            // 
            fromLbl.AutoSize = true;
            fromLbl.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            fromLbl.Location = new Point(133, 195);
            fromLbl.Margin = new Padding(4, 0, 4, 0);
            fromLbl.Name = "fromLbl";
            fromLbl.Size = new Size(60, 28);
            fromLbl.TabIndex = 12;
            fromLbl.Text = "From";
            // 
            // accountBox
            // 
            accountBox.DropDownStyle = ComboBoxStyle.DropDownList;
            accountBox.FormattingEnabled = true;
            accountBox.Location = new Point(236, 182);
            accountBox.Margin = new Padding(4, 3, 4, 3);
            accountBox.MaxDropDownItems = 2;
            accountBox.Name = "accountBox";
            accountBox.Size = new Size(188, 33);
            accountBox.TabIndex = 15;
            accountBox.SelectedIndexChanged += accountBox_SelectedIndexChanged;
            // 
            // accountBox2
            // 
            accountBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            accountBox2.FormattingEnabled = true;
            accountBox2.Location = new Point(236, 245);
            accountBox2.Margin = new Padding(4, 3, 4, 3);
            accountBox2.MaxDropDownItems = 2;
            accountBox2.Name = "accountBox2";
            accountBox2.Size = new Size(188, 33);
            accountBox2.TabIndex = 19;
            accountBox2.SelectedIndexChanged += accountBox2_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(133, 255);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(34, 28);
            label2.TabIndex = 20;
            label2.Text = "To";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(133, 313);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(88, 28);
            label1.TabIndex = 21;
            label1.Text = "Amount";
            label1.Click += label1_Click;
            // 
            // transferAmt
            // 
            transferAmt.Location = new Point(236, 310);
            transferAmt.Name = "transferAmt";
            transferAmt.Size = new Size(188, 31);
            transferAmt.TabIndex = 22;
            // 
            // cancelBtn
            // 
            cancelBtn.BackColor = Color.DarkTurquoise;
            cancelBtn.ForeColor = Color.Black;
            cancelBtn.Location = new Point(340, 405);
            cancelBtn.Margin = new Padding(4, 3, 4, 3);
            cancelBtn.Name = "cancelBtn";
            cancelBtn.Size = new Size(180, 57);
            cancelBtn.TabIndex = 23;
            cancelBtn.Text = "Go Back";
            cancelBtn.UseVisualStyleBackColor = false;
            cancelBtn.UseWaitCursor = true;
            cancelBtn.Click += cancelBtn_Click;
            // 
            // transferFrm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1000, 563);
            Controls.Add(cancelBtn);
            Controls.Add(transferAmt);
            Controls.Add(label1);
            Controls.Add(label2);
            Controls.Add(accountBox2);
            Controls.Add(OKBtn);
            Controls.Add(accountBox);
            Controls.Add(fromLbl);
            Controls.Add(pictureBox1);
            Controls.Add(AmountTxt);
            Margin = new Padding(4, 3, 4, 3);
            Name = "transferFrm";
            Text = "Transfer";
            Load += transferFrm_Load;
            DataContextChanged += accountBox_SelectedIndexChanged;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox AmountTxt;
        private PictureBox pictureBox1;
        private Button OKBtn;
        private Label fromLbl;
        private ComboBox accountBox;
        private ComboBox accountBox2;
        private Label label2;
        private Label label1;
        private TextBox transferAmt;
        private Button cancelBtn;
    }
}