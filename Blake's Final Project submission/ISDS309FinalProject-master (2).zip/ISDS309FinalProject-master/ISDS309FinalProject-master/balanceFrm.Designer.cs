﻿namespace ISDS309FinalProject
{
    partial class balanceFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            OKBtn = new Button();
            pictureBox1 = new PictureBox();
            label2 = new Label();
            SavingsAccountBalance = new Label();
            label3 = new Label();
            label4 = new Label();
            cancelBtn = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // OKBtn
            // 
            OKBtn.BackColor = SystemColors.ActiveCaption;
            OKBtn.Location = new Point(98, 395);
            OKBtn.Margin = new Padding(4);
            OKBtn.Name = "OKBtn";
            OKBtn.Size = new Size(179, 58);
            OKBtn.TabIndex = 8;
            OKBtn.Text = "OK";
            OKBtn.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.project_logo;
            pictureBox1.Location = new Point(530, 118);
            pictureBox1.Margin = new Padding(4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(386, 367);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            label2.ForeColor = Color.Green;
            label2.Location = new Point(98, 82);
            label2.Name = "label2";
            label2.Size = new Size(362, 38);
            label2.TabIndex = 12;
            label2.Text = "Checking Account Balance";
            label2.Click += label2_Click;
            // 
            // SavingsAccountBalance
            // 
            SavingsAccountBalance.AutoSize = true;
            SavingsAccountBalance.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            SavingsAccountBalance.ForeColor = Color.Green;
            SavingsAccountBalance.Location = new Point(111, 203);
            SavingsAccountBalance.Name = "SavingsAccountBalance";
            SavingsAccountBalance.Size = new Size(342, 38);
            SavingsAccountBalance.TabIndex = 13;
            SavingsAccountBalance.Text = "Savings Account Balance";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BorderStyle = BorderStyle.Fixed3D;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label3.Location = new Point(111, 118);
            label3.Name = "label3";
            label3.Size = new Size(65, 27);
            label3.TabIndex = 14;
            label3.Text = "label3";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BorderStyle = BorderStyle.Fixed3D;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label4.Location = new Point(111, 241);
            label4.Name = "label4";
            label4.Size = new Size(65, 27);
            label4.TabIndex = 15;
            label4.Text = "label4";
            // 
            // cancelBtn
            // 
            cancelBtn.BackColor = Color.DarkTurquoise;
            cancelBtn.ForeColor = Color.Black;
            cancelBtn.Location = new Point(311, 395);
            cancelBtn.Margin = new Padding(4, 3, 4, 3);
            cancelBtn.Name = "cancelBtn";
            cancelBtn.Size = new Size(180, 57);
            cancelBtn.TabIndex = 19;
            cancelBtn.Text = "Go Back";
            cancelBtn.UseVisualStyleBackColor = false;
            cancelBtn.UseWaitCursor = true;
            cancelBtn.Click += cancelBtn_Click;
            // 
            // balanceFrm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1000, 562);
            Controls.Add(cancelBtn);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(SavingsAccountBalance);
            Controls.Add(label2);
            Controls.Add(pictureBox1);
            Controls.Add(OKBtn);
            Margin = new Padding(4);
            Name = "balanceFrm";
            Text = "Balance";
            Load += balanceFrm_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button OKBtn;
        private PictureBox pictureBox1;
        private Label label2;
        private Label SavingsAccountBalance;
        private Label label3;
        private Label label4;
        private Button cancelBtn;
    }
}