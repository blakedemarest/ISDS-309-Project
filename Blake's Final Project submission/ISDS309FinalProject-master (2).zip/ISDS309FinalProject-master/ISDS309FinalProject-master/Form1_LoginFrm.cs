using System.Text;

namespace ISDS309FinalProject
{
    public partial class Form1_LoginFrm : Form
    {
        //This handles the application closing
        public static class FormUtilities
        {
            public static void CloseFormHandler(object sender, FormClosingEventArgs e)
            {
                UserDataService.GenerateAndDisplayReceipt(UserSession.CurrentUsername);
                Application.Exit(); // This will terminate the application when user presses the X
            }

            public static void CloseApplication(object sender, EventArgs e)
            {
                DialogResult result = MessageBox.Show($"Are you sure you want to exit?", "Confirm Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    UserDataService.GenerateAndDisplayReceipt(UserSession.CurrentUsername); 
                    Application.Exit(); //Terminates application when a button is pressed
                }
                
            }
        }

        //static class for getting receipt information
        public static class UserDataService
        {
            private static string filePath = "All_User_Accounts.txt";
            private static string receiptPath = "TransactionReceipt.txt";
            private static string initialData = "";
            private static string finalData = "";

            //logs user information upon login
            public static void CaptureInitialData(string username)
            {
                initialData = GetUserInformation(username);
            }

            //logs user information upon exit
            public static void GenerateAndDisplayReceipt(string username)
            {
                finalData = GetUserInformation(username);
                WriteReceiptToFile();
            }

            //gets user information from our text file. had to use StringBuilder and StreamWriter, I don't know how to use anything else when analyzing text files
            //for our code.
            private static string GetUserInformation(string username)
            {
                bool isCapturing = false;
                StringBuilder capturedData = new StringBuilder();

                string[] lines = File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    if (line.StartsWith("Username: ") && line.Substring(10).Trim() == username)
                    {
                        isCapturing = true;  // Start capturing after finding the username
                        continue;  // Skip the username line to avoid security issues
                    }

                    if (isCapturing)
                    {
                        if (line.StartsWith("=============================="))
                        {
                            capturedData.AppendLine(line);  // Append the end marker and prepare to stop
                            break;  // Stop capturing after the block ends
                        }

                        if (!line.StartsWith("Password: "))  // Filter out the password for security
                        {
                            capturedData.AppendLine(line);
                        }
                    }
                }

                return capturedData.ToString();
            }

            //Write's the receipt.
            private static void WriteReceiptToFile()
            {
                using (StreamWriter writer = new StreamWriter(receiptPath))
                {

                    writer.WriteLine("==================================================");
                    writer.WriteLine("                  TRANSACTION RECEIPT              ");
                    writer.WriteLine("==================================================");
                    writer.WriteLine();
                    writer.WriteLine("Before Changes");
                    writer.WriteLine("==============================");
                    writer.WriteLine(initialData);
                    writer.WriteLine();
                    writer.WriteLine("After Changes");
                    writer.WriteLine("==============================");
                    writer.WriteLine(finalData);
                    writer.WriteLine();
                    writer.WriteLine("==================================================");
                    writer.WriteLine("                  CUSTOMER SURVEY                  ");
                    writer.WriteLine("==================================================");
                    writer.WriteLine("We value your feedback to improve our service.");
                    writer.WriteLine("Please take a moment to answer the following question:");
                    writer.WriteLine();
                    writer.WriteLine("How satisfied are you with our banking services?");
                    writer.WriteLine("1. Very Satisfied   2. Satisfied   3. Neutral   4. Unsatisfied   5. Very Unsatisfied");
                    writer.WriteLine();
                    writer.WriteLine("Please visit our website or contact our support team to provide your feedback.");
                    writer.WriteLine("Thank you for banking with us!");
                    writer.WriteLine();
                    writer.WriteLine("==================================================");
                    writer.WriteLine("                 END OF TRANSACTION                ");
                    writer.WriteLine("==================================================");
                }
            }

        }


        //gets the username for 

        //I couldn't figure out how to get the first name, last name, and user ID out of my
        public static class UserSession
        {
            public static string CurrentUsername { get; set; } = "";
            public static bool CheckingAccount { get; set; } //These are implemented so that ChooseAccountFrm knows which account to get into for withdrawals/deposits
            public static bool SavingsAccount { get; set; } //These are implemented so that ChooseAccountFrm knows which account to get into for withdrawals/deposits
            public static string CurrentFirstName { get; set; } = "";

            public static string CurrentLastName { get; set; } = "";

            public static string CurrentUserID { get; set; } = "";

        }
        private bool VerifyLogin(string username, string password)
        {
            string allUsersFilePath = "All_User_Accounts.txt";
            try
            {
                if (File.Exists(allUsersFilePath))
                {
                    //this reads our entire database (found in our debug) and matches it with the username entered.
                    string[] lines = File.ReadAllLines(allUsersFilePath);
                    for (int i = 0; i < lines.Length; i++)
                    {
                        Console.WriteLine($"Checking line: {lines[i]}"); 
                        
                        if (lines[i].StartsWith("Username: ") && lines[i].Substring(10).Trim().Equals(username, StringComparison.OrdinalIgnoreCase))
                        {
                            // This sucked, but its how our system authenticates the password.
                            if (i + 1 < lines.Length && lines[i + 1].StartsWith("Password: ") && lines[i + 1].Substring(10).Trim().Equals(password))
                            {
                                return true; // Correct username and password match
                            }
                            break; // Found username but password does not match
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error checking username and password: {ex.Message}");
                //this shouldn't happen but its here just in case.
            }
            return false; // Username not found or password does not match
        }

        //This is the method I've been using to swap windows everytime a new window is opened.
        //Without it, the user would have every window open at once.
        //I implemented this before I knew about public classes so every form has a unique ShowForm.
        private void ShowForm(Form form)
        {
            this.Hide(); // Hide the main menu
            //form.FormClosed += (s, args) => this.Show(); // Show the main menu again when the form is closed
            form.Show(); // Show the form
        }

        private void FormClosingEvent(object sender, FormClosingEventArgs e)
        {
            // Check if the close reason is user closing the form via the 'X' button
            if (e.CloseReason == CloseReason.UserClosing)
            {
                // Ask the user to confirm they want to exit
                DialogResult result = MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                // If the user clicks 'No', cancel the closing of the form
                if (result == DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
            // If the form is closing for other reasons (like shutdown, system restart, etc.), handle accordingly
            else
            {
                // Additional handling or simply allow the form to close
            }
        }



        public Form1_LoginFrm()
        {
            InitializeComponent();

        }

       
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void usernameTxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void createBtn_Click(object sender, EventArgs e)
        {
            ShowForm(new CreateAccountFrm());
        }

        //Login Button
        private void loginBtn_Click(object sender, EventArgs e)
        {
            string username = usernameTxt.Text.Trim();
            string password = passwordTxt.Text.Trim();

            if (VerifyLogin(username, password))
            {
                UserSession.CurrentUsername = username;

                MessageBox.Show("Login successful!");
                UserDataService.CaptureInitialData(UserSession.CurrentUsername);

                ShowForm(new mainmenuFrm());
            }
            else
            {
                MessageBox.Show("Invalid username/password, please try again.");
            }
        }

        private void loginFrm_Load(object sender, EventArgs e)
        {
            
        }
    }
}
