﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ISDS309FinalProject.Form1_LoginFrm;

namespace ISDS309FinalProject
{
    public partial class transferFrm : Form
    {
        private withdrawalFrm withdrawalForm = new withdrawalFrm();
        private depositFrm depositForm = new depositFrm();
        public transferFrm()
        {
            InitializeComponent();
            InitializeAccountBoxes();
            this.FormClosing += FormUtilities.CloseFormHandler;
        }

        private void ShowForm(Form form)
        {
            this.Hide(); // Hide the main menu
            form.FormClosed += (s, args) => this.Show(); // Show the main menu again when the form is closed
            form.Show(); // Show the form
        }

        private void InitializeAccountBoxes()
        {

            accountBox.Items.Add("Checkings");
            accountBox.Items.Add("Savings");

            accountBox2.Items.Add("Checkings");
            accountBox2.Items.Add("Savings");

            accountBox.SelectedIndex = 0;  // Default to Checking
            accountBox2.SelectedIndex = 1;  // Default to Savings
        }

        private void accountBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void transferFrm_Load(object sender, EventArgs e)
        {

        }

        private void toLbl_Click(object sender, EventArgs e)
        {

        }

        private void accountBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void OKBtn_Click(object sender, EventArgs e)
        {
            double amount;
            double remainingBalanceWithdraw;
            double remainingBalanceDeposit;

            // Assume transferAmt is a TextBox or similar control
            if (!double.TryParse(transferAmt.Text, out amount))
            {
                MessageBox.Show("Please enter a valid amount.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (accountBox.Text == accountBox2.Text)
            {
                MessageBox.Show("You cannot transfer between the same account.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Perform withdrawal from the first account
            if (withdrawalForm.UpdateAccountBalanceWithdraw(amount, out remainingBalanceWithdraw))
            {
                // Perform deposit to the second account
                if (depositForm.UpdateAccountBalanceDeposit(amount, out remainingBalanceDeposit))
                {
                    MessageBox.Show($"Transfer successful. New balance in the target account: ${remainingBalanceDeposit:0.00}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Transfer failed during deposit.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Transfer failed during withdrawal.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            ShowForm(new mainmenuFrm());
        }
    }
}
