﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ISDS309FinalProject.Form1_LoginFrm;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace ISDS309FinalProject
{
    public partial class withdrawalFrm : Form
    {
        public withdrawalFrm()
        {
            InitializeComponent();
            this.FormClosing += FormUtilities.CloseFormHandler;
        }

        private void ShowForm(Form form)
        {
            this.Hide(); // Hide the main menu
            form.FormClosed += (s, args) => this.Show(); // Show the main menu again when the form is closed
            form.Show(); // Show the form
        }

        public bool UpdateAccountBalanceWithdraw(double amount, out double remainingBalance)
        {
            string allUsersFilePath = "All_User_Accounts.txt";
            string tempFilePath = Path.GetTempFileName();
            bool updateSuccessful = false;
            remainingBalance = 0.0;  // Initialize remaining balance
            double currentBalance = 0;
            string username = UserSession.CurrentUsername;
            string accountType = UserSession.CheckingAccount ? "Checking" : "Savings";

            try
            {
                string[] lines = File.ReadAllLines(allUsersFilePath);
                using (StreamWriter writer = new StreamWriter(tempFilePath))
                {
                    bool isUserFound = false;

                    for (int i = 0; i < lines.Length; i++)
                    {
                        if (isUserFound)
                        {
                            if (lines[i].StartsWith(accountType + " Account Balance:"))
                            {
                                string balanceString = lines[i].Split('$')[1].Trim();
                                currentBalance = double.Parse(balanceString);
                                if (currentBalance >= amount)
                                {
                                    currentBalance -= amount;
                                    lines[i] = $"{accountType} Account Balance: ${currentBalance:0.00}";
                                    writer.WriteLine(lines[i]);
                                    updateSuccessful = true;
                                    remainingBalance = currentBalance;  // Update the remaining balance
                                    continue;
                                }
                                else
                                {
                                    MessageBox.Show($"Insufficient funds for this transaction. Available funds: ${currentBalance:0.00}");
                                    writer.WriteLine(lines[i]);
                                    break;
                                }
                            }
                        }

                        if (lines[i].StartsWith("Username: ") && lines[i].Substring(10).Trim().Equals(username))
                        {
                            isUserFound = true;
                        }

                        writer.WriteLine(lines[i]);
                    }
                }

                if (updateSuccessful)
                {
                    File.Copy(tempFilePath, allUsersFilePath, true);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating account balance: {ex.Message}\nCurrent Balance: ${currentBalance:0.00}");
            }
            finally
            {
                File.Delete(tempFilePath);
            }

            return updateSuccessful;
        }

        private void WithdrawalMessage(double amount)
        {
            string accountType = UserSession.CheckingAccount ? "Checking" : "Savings";  // Determine the account type
                                                                                        // Prompt the user to confirm the withdrawal
            DialogResult result = MessageBox.Show($"Are you sure you want to withdraw ${amount:0.00} from your {accountType} account?", "Confirm Withdrawal", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            // Check the user's response
            if (result == DialogResult.Yes)
            {
                double remainingBalance;
                UpdateAccountBalanceWithdraw(amount, out remainingBalance);
                MessageBox.Show($"Successfully withdrew ${amount} from your account!");
            }
            else
            {
                MessageBox.Show("Withdrawal cancelled.", "Transaction Cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }




        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void fortyBtn_Click(object sender, EventArgs e)
        {
            WithdrawalMessage(40.00);
        }

        private void eightyBtn_Click(object sender, EventArgs e)
        {
            WithdrawalMessage(80.00);
        }

        private void hundredBtn_Click(object sender, EventArgs e)
        {
            WithdrawalMessage(100.00);
        }

        private void twohundredBtn_Click(object sender, EventArgs e)
        {
            WithdrawalMessage(200.00);
        }

        private void otherBtn_Click(object sender, EventArgs e)
        {
            string input = Microsoft.VisualBasic.Interaction.InputBox("Enter the amount to withdraw:", "Withdraw", "0", -1, -1);
            if (double.TryParse(input, out double customAmount) && customAmount > 0)
            {
                WithdrawalMessage(customAmount);
            }
            else
            {
                MessageBox.Show("Invalid amount entered.");
            }
        }

        private void OKBtn_Click(object sender, EventArgs e)
        {

        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            ShowForm(new mainmenuFrm());
        }
    }
}
